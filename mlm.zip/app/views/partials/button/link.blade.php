<a href="{{$link}}" class="btn btn-info">
    
    {{$title}}
</a>