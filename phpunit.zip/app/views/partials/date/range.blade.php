   <div class="form-group">
                <label>Date and time range:</label>

                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-clock-o"></i>
                  </div>
                  <input class="form-control pull-right active" id="reservationtime" name='range' type="text">
                </div>
                <!-- /.input group -->
              </div>