@extends('template.mlm.layout1')


@section('navigation')
<ul class="navigation">
                        <li>
                            <a href="/admin/users">Users</a>
                            
                        </li>
                        <li>
                            <a href="/admin/orders">Orders</a>
                            
                        </li>
                        <li>
                            <a href="/admin/withdraws">Withdraws</a>
                            
                        </li>
                          <li>
                            <a href="/admin/logout">logout</a>
                            
                        </li>
                       
                    </ul>
@stop
@section('footer')
 <div class="page-footer">
                
                <!-- page footer wrap -->
                <div class="page-footer-wrap bg-dark-gray">
                    <!-- page footer holder -->
                    <div class="page-footer-holder page-footer-holder-main">
                                                
                            <!-- ./contacts -->
                            
                        </div>
                        
                    </div>
                    <!-- ./page footer holder -->
                </div>
@stop
@section('developedBy')


<div class="page-footer-wrap bg-darken-gray">
                    <!-- page footer holder -->
                    <div class="page-footer-holder">
                        
                        <!-- copyright -->
                        <div class="copyright">
                           
                            © 2014  DEVELOPED BY <a href="https://www.facebook.com/muhammadusama.riaz.7">MUHAMMAD USAMA RIAZ (+923118222625)</a> - All Rights Reserved                            
                        </div>
                        <!-- ./copyright -->
                        
                        <!-- social links -->
                        <div class="social-links">
                            <a href="https://www.facebook.com/WEBdevelopmentXtream?ref=e4earning.com"><span class="fa fa-facebook"></span></a>
                            <a href="https://www.facebook.com/WEBdevelopmentXtream?ref=e4earning.com"><span class="fa fa-twitter"></span></a>
                            <a href="https://www.facebook.com/WEBdevelopmentXtream?ref=e4earning.com"><span class="fa fa-google-plus"></span></a>
                            <a href="https://www.facebook.com/WEBdevelopmentXtream?ref=e4earning.com"><span class="fa fa-linkedin"></span></a>
                            <a href="https://www.facebook.com/WEBdevelopmentXtream?ref=e4earning.com"><span class="fa fa-vimeo-square"></span></a>
                            <a href="https://www.facebook.com/WEBdevelopmentXtream?ref=e4earning.com"><span class="fa fa-dribbble"></span></a>
                        </div>                        
                        <!-- ./social links -->
                        
                    </div>
                    <!-- ./page footer holder -->
                </div>

@stop	