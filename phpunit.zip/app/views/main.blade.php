@extends('template.mlm.layout1')


@section('navigation')
<ul class="navigation">
                        <li>
                            <a href="index">Home</a>
                            
                        </li>
                        <li>
                            <a href="aboutus">About US</a>
                            
                        </li>
                        <li>
                            <a href="contactus">Contact US</a>
                            
                        </li>
                         <li>
                            <a href="oppertunity">oppertunity</a>
                            
                        </li>
                        <li>
                            <a href="login">Login</a>
                            
                        </li>
                        <li>
                            <a href="register">Register</a>
                            
                        </li>
                        
                    </ul>
@stop
@section('footer')
 <div class="page-footer">
                
                <!-- page footer wrap -->
                <div class="page-footer-wrap bg-dark-gray">
                    <!-- page footer holder -->
                    <div class="page-footer-holder page-footer-holder-main">
                                                
                        <div class="row">
                            
                            <!-- about -->
                            <div class="col-md-3">
                                <h3>aaa</h3>
                                <p>aaaaaaaaaaaaaaaaaaaaaaaaaa aaaaaaaa a.</p>
                            </div>
                            <!-- ./about -->
                            
                            <!-- quick links -->
                            <div class="col-md-3">
                                <h3>Quick links</h3>
                                
                                <div class="list-links">
                                    <a href="index">Home</a>                                    
                                    <a href="aboutus">aboutus</a>
                                    <a href="contactus">contactus</a>
                                    <a href="login">login</a>
                                      <a href="	register">register</a>
                                </div>                                
                            </div>
                            <!-- ./quick links -->
                            
                            <!-- recent tweets -->
		                            <div class="col-md-3">
		                                <h3>Recent Updates</h3>
		                                
		                                
		                                
		                            </div>
                            <!-- ./recent tweets -->
                            
                            <!-- contacts -->
                            <div class="col-md-3">
                                <h3>Contacts</h3>
                                
                                <div class="footer-contacts">
                                    <div class="fc-row">
                                        <span class="fa fa-home"></span>
                                        000 asad, 13aasd 111,<br/> 
                                        Casdakahe, OK 231
                                    </div>
                                    <div class="fc-row">
                                        <span class="fa fa-phone"></span>
                                        (123) 456-2222
                                    </div>
                                    <div class="fc-row">
                                        <span class="fa fa-envelope"></span>
                                        <strong>Muhammad Usama Riaz</strong><br>
                                        <a href="mailto:#">info@mlm.com</a>
                                    </div>                                    
                                </div>
                                
                                

                                
                            </div>
                            <!-- ./contacts -->
                            
                        </div>
                        
                    </div>
                    <!-- ./page footer holder -->
                </div>
@stop
@section('developedBy')

<div class="page-footer-wrap bg-darken-gray">
                    <!-- page footer holder -->
                    <div class="page-footer-holder">
                        
                        <!-- copyright -->
                        <div class="copyright">
                           
                            © 2015  DEVELOPED BY <a href="https://www.facebook.com/muhammadusama.riaz.7">MUHAMMAD USAMA RIAZ (+923118222625)</a> - All Rights Reserved                            
                        </div>
                        <!-- ./copyright -->
                        
                        <!-- social links -->
                        <div class="social-links">
                            <a href="https://www.facebook.com/WEBdevelopmentXtream?ref=e4earning.com"><span class="fa fa-facebook"></span></a>
                            <a href="https://www.facebook.com/WEBdevelopmentXtream?ref=e4earning.com"><span class="fa fa-twitter"></span></a>
                            <a href="https://www.facebook.com/WEBdevelopmentXtream?ref=e4earning.com"><span class="fa fa-google-plus"></span></a>
                            <a href="https://www.facebook.com/WEBdevelopmentXtream?ref=e4earning.com"><span class="fa fa-linkedin"></span></a>
                            <a href="https://www.facebook.com/WEBdevelopmentXtream?ref=e4earning.com"><span class="fa fa-vimeo-square"></span></a>
                            <a href="https://www.facebook.com/WEBdevelopmentXtream?ref=e4earning.com"><span class="fa fa-dribbble"></span></a>
                        </div>                        
                        <!-- ./social links -->
                        
                    </div>
                    <!-- ./page footer holder -->
                </div>

@stop	