@extends('adminmain')





@section('content')
WELCOME TO ADMIN PANEL


@stop