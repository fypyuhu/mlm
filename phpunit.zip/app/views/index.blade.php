@extends('main')

@section('slider')

@stop


@section('content')


<div class="page-content-wrap bg-img-1">

                    <div class="divider"><div class="box"><span class="fa fa-angle-down"></span></div></div>                    
                    
                    <!-- page content holder -->
                    <div class="page-content-holder">
                        
                        <div class="row">
                            <div class="col-md-8 this-animate animated fadeInLeft this-animated" data-animate="fadeInLeft">
                                
                                <div class="block-heading block-heading-centralized">
                                    <h2 class="heading-underline"> Welcome To e4earning</h2>
                                    <div class="block-heading-text">
                                      E4earning is well designed online membership Matrix system that guarantee income without much efforts or selling goods to other peoples in order to make commission. If you ready to earn extra money without much efforts you have came to right location, It's your destiny for bright future. No need to worry about complex chain systems it's simple yet efficient 4x7 Matrix. To get Right Direction just read below we will tell you how dreams comes true. We know for someone to be successful in today's online membership plans, We should provide easy, simple yet reliable ways to get step forward and earn enough for what they pay and what efforts they spend, Now we have came with very simple yet reliable and efficient 4x7 Matrix which can produce unbelievable Cash for you.
The Power of FORCE 4X7 Matrixes

  <br> The person you referred pay membership fee will be placed under your matrix in your first level or level below if above level is already filled.
 <br>   If person referred by anyone in your down line upgrade it will automatically be added to your matrix and will result in payout.
<br>    If person referred by anyone in your up line upgrade there are 95% chances that you will get rewarded if he end up in your matrix.
 <br>  If person referred by none upgrade, we don't consume its bonus and our algorithm decide whom to award, so anyone who is unable to refer anyone and unlucky with above mentioned options then he may get rewarded for his loyalty.
 <br>    The system will do the work for you! But Of course, this doesn't happen overnight.






                                    </div>
                                </div>
                               <!-- <div class="block this-animate animated fadeInLeft this-animated" data-animate="fadeInLeft">
                                    <img src="assets/pm.png" class="img-responsive">
                                </div>-->
                            </div>
                           <div class="col-md-4 this-animate text-center animated fadeInRight this-animated" data-animate="fadeInRight">
                               <div class="carousel-inner">
                               
			               <div id="sliderFrame">
					        <div id="slider">
					            <a href="http://www.menucool.com/javascript-image-slider" target="_blank">
					                <img src="images/image-slider-1.jpg" alt="Welcome to Menucool.com" />
					            </a>
					            <img src="images/image-slider-2.jpg" alt="" />
					            <img src="images/image-slider-3.jpg" alt="Pure Javascript. No jQuery. No flash." />
					            <img src="images/image-slider-4.jpg" alt="#htmlcaption" />
					            <img src="images/image-slider-5.jpg" />
					        </div>
					        <div id="htmlcaption" style="display: none;">
					            <em>HTML</em> caption. Link to <a href="http://www.google.com/">Google</a>.
					        </div>
					    </div>   
					    </div>  
                        </div>
                        
                        
                        
                    </div>
                    <!-- ./page content holder -->
                </div>




                <div class="page-content-wrap bg-texture-1 bg-dark light-elements">
                    
                    <div class="divider"><div class="box"><span class="fa fa-angle-down"></span></div></div>
                    
                    <!-- page content holder -->
                    <div class="page-content-holder">
                                                
                        <div class="row">
                            
                            <div class="col-md-4">                                
                                <div class="text-column text-column-centralized tex-column-icon-lg this-animate animated fadeInLeft this-animated" data-animate="fadeInLeft">
                                    <div class="text-column-icon">
                                        <span class="fa fa-support"></span>
                                    </div>
                                    <h4>Free  Support</h4>
                                    <div class="text-column-info">
                                        We provide <strong>free</strong> support for each User. 
                                    </div>
                                </div>                                
                            </div>
                            
                            <div class="col-md-4">                                
                                <div class="text-column text-column-centralized tex-column-icon-lg this-animate animated fadeInUp this-animated" data-animate="fadeInUp">
                                    <div class="text-column-icon">
                                        <span class="fa fa-expand"></span>
                                    </div>
                                    <h4>Short Way to be Richer</h4>
                                    <div class="text-column-info">
                                       You are very near to make extra income and get Richer.
                                    </div>
                                </div>                                
                            </div>
                            
                            <div class="col-md-4">                                
                                <div class="text-column text-column-centralized tex-column-icon-lg this-animate animated fadeInRight this-animated" data-animate="fadeInRight">
                                    <div class="text-column-icon">
                                        <span class="fa fa-clock-o"></span>
                                    </div>
                                    <h4>Time Saver</h4>
                                    <div class="text-column-info">
                                        Our web site is made very easy to understand <strong>only $23</strong>.
                                    </div>
                                </div>                                
                            </div>
                            
                        </div>
                        
                    </div>
                    <!-- ./page content holder -->
                </div>


@stop