@extends('adminmain')





@section('content')


<table border="2" >
	<tr>
	<th>ID</th> 
        <th>userID</th>
        <th>username</th> 
        <th>name</th> 
        <th>Mobile</th> 
        <th>Product Id</th>  
        <th>Product Tilte</th> 
        <th>Product Details</th> 
        <th>Product Price</th> 
        <th>Reciever Name</th>
        <th>Reciever Address</th>
        <th>Reciever City</th>
        <th>Reciever Country</th> 
        <th>Reciever Mobile</th>
        <th>Order Date</th>
        <th>Status</th> 
        <th>Action</th> 
	</tr>
	@foreach ($orders as $o)
	<tr>
	 
          		<th>{{@$o->id}}</th> 
                        <th>{{@$o->userId}}</th> 
			<th>{{@$o->username}}</th>
                        <th>{{@$o->name}}</th>
			<th>{{@$o->mobileno}}</th>
			<th>{{@$o->pId}}</th>
			<th>{{@$o->pTitle}}</th>
			<th>{{@$o->pDetails}}</th>
			<th>{{@$o->pPrice}}</th>
			<th>{{@$o-> oRname}}</th>
			<th>{{@$o-> oAddress}}</th>
			<th>{{@$o-> oCity}}</th>
			<th>{{@$o-> oCountry}}</th>
			<th>{{@$o-> oMobile}}</th>
			<th>{{@$o-> oDate}}</th>
			<th>{{@$o-> oStatus}}</th>
			

	  <th>
              @if($o->oStatus == 'Pending')
              <form method="post">     
                  
		<input type="hidden" name="userId" value="{{$o->userId}}" />
                <input type="hidden" name="id" value="{{$o->id}}" />
                <input type="hidden" name="price" value="{{$o->pPrice}}" />
                
                <input type="submit"  value="delivered" name='btn'>
                </form>
                <form method="post">                    
		<input type="hidden" name="userId" value="{{$o->userID}}" />
                <input type="hidden" name="id" value="{{$o->id}}" />
	
                <input type="submit"  value="cancel" name='btn'>
                </form>
          </th> 
	  @endif
	</tr>
     @endforeach	
</table>


@stop