<?php



class Withdraw extends Eloquent {
public $timestamps = false;
	

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'withdraws';

	/**
	 * The attributes excluded from the model's JSON form.
	 *
	 * @var array
	 */


}
