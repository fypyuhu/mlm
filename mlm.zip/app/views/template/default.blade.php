<<!DOCTYPE html>
<html>
<head>
@yield('includings')
	<title>
		@yeild('pageTitle')


	</title>
</head>

<body>
@yield('header')
@yield('content')
@yield('footer')

</body>
</html>