<div class="box-footer">
    <button type="submit" class="btn btn-primary">Submit</button>
</div>