<?php

class AdminController extends BaseController{
	function logout(){
		Session::put('admin',0);

	}
	function  givepayment(){
		//$username = Input::get('username');
		//$userC = new	UserController();

	//	$userC->payToParents($username);
		return "Commition has been given ";
	}
	function postWithdraws(){
		if($this->isLogged())
		{
			$ID = Input::get('withdrawID');
			$status = Input::get('status');

				Withdraw::where('id', $ID)
				->update(array('status' => $status));
		
			return $this->getWithdraws();
		}
	}
	function updateUser(){
		if($this->isLogged())
		{
			$userID = Input::get('userID');
			$balance = Input::get('balance');
			$earned = Input::get('earned');
			$pmAccount = Input::get('pmAccount');
			$pmBatchNo = Input::get('pmBatchNo');
			$pmAmmount = Input::get('pmAmmount');
			$status = Input::get('status');

			User::where('ID', $userID)
			->update(array('balance' => $balance , 'earned' => $earned , 'pmAccount' => $pmAccount ,'pmBatchNo' =>$pmBatchNo , 'pmAmmount' => $pmAmmount , 'status' => $status));


			return $this->usersPage();

		}
	}
	function getUsers(){
		if($this->isLogged())
		{
			$users = User::all();
				return View::make('adminusers',['users'=>$users]);
		}
			return 	$this->loginPage();
		

	}
	function getWithdraws(){
		if($this->isLogged())
			$Withdraws = Withdraw::all();
				return View::make('adminwithdraws',['withdraws'=>$Withdraws]);
			return 	$this->loginPage();

	}

	function indexPage(){
			if($this->isLogged())
				return View::make('adminindex');
			return 	$this->loginPage();
	}

	function loginPage(){

		return View::make('adminlogin');


	}
	function chechCorectAuth($admin){
		return ($admin['username'] == "admin" && $admin['password'] == "admin");

	}
	function login(){
		//return "aa";
		$username = Input::get('username');
		$password = Input::get('password');
		$admin = array('username' =>$username  , 'password' =>$password);
		if($this->chechCorectAuth($admin)){
				
			Session::put('admin',$admin);

		return 	$this->indexPage();

		}
		
		return 	$this->loginPage();	


	}

	function isLogged(){

		if(!Session::has('admin') )
			return 0;

		$admin  = Session::get('admin');
	
		if($admin == NULL)
			return 0;	
	

		if ($this->chechCorectAuth($admin))
			return $admin;

				
			
		
		return 0;

	}

        function getOrders(){
            	if($this->isLogged()){
			$orders = OrderView::all();
				return View::make('adminorders',['orders'=>$orders]);
                
                                
                }
                return 	$this->loginPage();

        
        }
        function postOrders(){
            	if($this->isLogged()){
                    if(Input::get('btn') =='delivered')
                    {
                      $this->deliveredOrder();
                    return $this->ordersPage();    
                    }
                    if(Input::get('btn') =='cancel')
                    {
                        
                      $this->cancelOrder();
                    return $this->ordersPage();
                    
                    }
                    
                                
                }
                return 	$this->loginPage();

        
        }
        
        function deliveredOrder(){
            $userId = Input::get('userId');
            $id = Input::get('id');
            $price = Input::get('price');
            
            $this->incPurcahseBalanceToUser($userId, $price);
            
            
            Order::where('id',$id)->update([
                'status' =>'Delvered'
                
            ]);
        }
        function cancelOrder(){
            $id = Input::get('id');
            Order::where('id',$id)->update([
                'status' =>'Canceled'
                
            ]);
            
        }
        function incPurcahseBalanceToUser($userId,$price){
            $user = User::where('ID',$userId);
            $userp = $user->first();
           $purchasingBalance =  $userp->pbalance;
            $purchasingBalance += $price;
           $user->update(['pbalance' => $purchasingBalance]);
           
            $userC = new	UserController();
               
           if($purchasingBalance >= 3000){
                
                if($purchasingBalance-$price <3000)
                    $userC->payToParentsWithAmmount($userp->username, $purchasingBalance);
                else 
                     $userC->payToParentsWithAmmount($userp->username, $price);
                
                
           }
           
        }
}

?> 