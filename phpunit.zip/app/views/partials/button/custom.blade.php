<div class="box-footer">
    <button type="submit" class="btn btn-primary">{{$value}}</button>
</div>