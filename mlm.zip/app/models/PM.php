<?php

class PM extends \Eloquent {
    	protected $table = 'pms';

	protected $fillable = [];
}