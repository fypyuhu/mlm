<!DOCTYPE html>
<html lang="en">
    <head>
        <!-- META SECTION -->
        <title>MLM</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <!-- END META SECTION -->
        <link href="/themes/1/js-image-slider.css" rel="stylesheet" type="text/css" />
   	 <script src="/themes/1/js-image-slider.js" type="text/javascript"></script>
    	<link href="/generic.css" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" type="text/css" href="/css/revolution-slider/extralayers.css" media="screen" />
        <link rel="stylesheet" type="text/css" href="/css/revolution-slider/settings.css" media="screen" />
        
        <link rel="stylesheet" type="text/css" href="/css/styles.css" media="screen" />                  

    </head>
    <body>
        <!-- page container -->
        <div class="page-container">
            
            <!-- page header -->
            <div class="page-header">
                
                <!-- page header holder -->
                <div class="page-header-holder">
                    
                    <!-- page logo -->
                    <div class="logo">
                        <a href="index">MLM</a>
                    </div>
                    <!-- ./page logo -->
                    

                    <!-- search -->
                   
                    <!-- ./search -->

                    <!-- nav mobile bars -->
                    <div class="navigation-toggle">
                        <div class="navigation-toggle-button"><span class="fa fa-bars"></span></div>
                    </div>
                    <!-- ./nav mobile bars -->
                    
                    <!-- navigation -->
                    @yield('navigation')
                    
                    <!-- ./navigation -->                        

                    
                </div>
                <!-- ./page header holder -->
                
            </div>
            <!-- ./page header -->
            
            <!-- page content -->
            <div>
            <div class="page-content ">
                @yield('slider')
                @yield('content')
                <!-- revolution slider -->
                                        
                <!-- ./revolution slider -->                        
                
                <!-- page content wrapper -->
                    
                <!-- page content wrapper -->                
                    
            <!-- ./page content -->
            
            <!-- page footer -->
                @yield('footer')

                <!-- ./page footer wrap -->
              
                <!-- page footer wrap -->
                
                <!-- ./page footer wrap -->
                
            </div>
            <!-- ./page footer -->
            
        </div>        
        <!-- ./page container -->
        
        <!-- page scripts -->
        <script type="text/javascript" src="/js/plugins/jquery/jquery.min.js"></script>
        <script type="text/javascript" src="/js/plugins/bootstrap/bootstrap.min.js"></script>
        
        <script type="text/javascript" src="/js/plugins/mixitup/jquery.mixitup.js"></script>
        <script type="text/javascript" src="/js/plugins/appear/jquery.appear.js"></script>
        
        <script type="text/javascript" src="/js/plugins/revolution-slider/jquery.themepunch.tools.min.js"></script>
        <script type="text/javascript" src="/js/plugins/revolution-slider/jquery.themepunch.revolution.min.js"></script>
        
        <script type="text/javascript" src="/js/actions.js"></script>
        <script type="text/javascript" src="/js/slider.js"></script>
        <!-- ./page scripts -->
    </body>
</html>


@if(Session::has('message'))
<?php $message = Session::get("message");?>
    @if(is_array($message))
        <script>alert('@foreach($message as $m) {{$m}} @endforeach')</script>"
    @else
    
        <script>alert('{{$message}}')</script>"

    @endif



    <?php Session::put(['message',""]); ?>
   
@endif



<developer>Muhammad Usama Riaz Mobile:031182226255</developer>
    