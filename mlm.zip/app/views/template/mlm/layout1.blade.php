<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from shapebootstrap.net/demo/html/xeon/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 12 Feb 2016 21:12:12 GMT -->
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">
<title>Xeon | OnePage Responsive Theme</title>
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/font-awesome.min.css" rel="stylesheet">
<link href="css/prettyPhoto.css" rel="stylesheet">
<link href="css/main.css" rel="stylesheet">
<!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
<link rel="shortcut icon" href="images/ico/favicon.ico">
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
<link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head> 
<body data-spy="scroll" data-target="#navbar" data-offset="0">
<header id="header" role="banner">
<div class="container">
<div id="navbar" class="navbar navbar-default">
<div class="navbar-header">
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
<span class="sr-only">Toggle navigation</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand" href="index-2.html"></a>
</div>
<div class="collapse navbar-collapse">
<ul class="nav navbar-nav">
<li class="active"><a href="#main-slider"><i class="icon-home"></i></a></li>
<li><a href="#services">Services</a></li>
<li><a href="#portfolio">Portfolio</a></li>
<li><a href="#pricing">Pricing</a></li>
<li><a href="#about-us">About Us</a></li>
<li><a href="#contact">Contact</a></li>
<li>  <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#login">Login</button>

</li>
<li>  <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#register">Register</button>
</li>
</ul>
</div>
</div>
</div>
</header> 
<section id="main-slider" class="carousel">
<div class="carousel-inner">
<div class="item active">
<div class="container">
<div class="carousel-content">
<h1>Free Onepage Theme</h1>
<p class="lead">Xeon is the best free onepage responsive theme available arround the globe<br>Download it right now for free</p>
</div>
</div>
</div> 
<div class="item">
<div class="container">
<div class="carousel-content">
<h1>ShapeBootstrap.net</h1>
<p class="lead">Download free but 100% premium quaility twitter Bootstrap based WordPress and HTML themes <br>from shapebootstrap.net</p>
</div>
</div>
</div> 
</div> 
<a class="prev" href="#main-slider" data-slide="prev"><i class="icon-angle-left"></i></a>
<a class="next" href="#main-slider" data-slide="next"><i class="icon-angle-right"></i></a>
</section> 
<section id="services">
<div class="container">
<div class="box first">
<div class="row">
<div class="col-md-4 col-sm-6">
<div class="center">
<i class="icon-apple icon-md icon-color1"></i>
<h4>iOS development</h4>
<p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae.</p>
</div>
</div> 
<div class="col-md-4 col-sm-6">
<div class="center">
<i class="icon-android icon-md icon-color2"></i>
<h4>Android development</h4>
<p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae.</p>
</div>
</div> 
<div class="col-md-4 col-sm-6">
<div class="center">
<i class="icon-windows icon-md icon-color3"></i>
<h4>Windows Phone development</h4>
<p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae.</p>
</div>
</div> 
<div class="col-md-4 col-sm-6">
<div class="center">
<i class="icon-html5 icon-md icon-color4"></i>
<h4>Ruby on Rails development</h4>
<p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae.</p>
</div>
</div> 
<div class="col-md-4 col-sm-6">
<div class="center">
<i class="icon-css3 icon-md icon-color5"></i>
<h4>Javascript development</h4>
<p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae.</p>
</div>
</div> 
<div class="col-md-4 col-sm-6">
<div class="center">
<i class="icon-thumbs-up icon-md icon-color6"></i>
<h4>Responsive web design</h4>
<p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae.</p>
</div>
</div> 
</div> 
</div> 
</div> 
</section> 
<section id="portfolio">
<div class="container">
<div class="box">
<div class="center gap">
<h2>Portfolio</h2>
<p class="lead">Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac<br>turpis egestas. Vestibulum tortor quam, feugiat vitae.</p>
</div> 
<ul class="portfolio-filter">
<li><a class="btn btn-primary active" href="#" data-filter="*">All</a></li>
<li><a class="btn btn-primary" href="#" data-filter=".bootstrap">Bootstrap</a></li>
<li><a class="btn btn-primary" href="#" data-filter=".html">HTML</a></li>
<li><a class="btn btn-primary" href="#" data-filter=".wordpress">Wordpress</a></li>
</ul> 
<ul class="portfolio-items col-4">
<li class="portfolio-item apps">
<div class="item-inner">
<div class="portfolio-image">
<img src="images/portfolio/thumb/item1.jpg" alt="">
<div class="overlay">
<a class="preview btn btn-danger" title="Lorem ipsum dolor sit amet" href="images/portfolio/full/item1.jpg"><i class="icon-eye-open"></i></a>
</div>
</div>
<h5>Lorem ipsum dolor sit amet</h5>
</div>
</li> 
<li class="portfolio-item joomla bootstrap">
<div class="item-inner">
<div class="portfolio-image">
<img src="images/portfolio/thumb/item2.jpg" alt="">
<div class="overlay">
<a class="preview btn btn-danger" title="Lorem ipsum dolor sit amet" href="images/portfolio/full/item2.jpg"><i class="icon-eye-open"></i></a>
</div>
</div>
<h5>Lorem ipsum dolor sit amet</h5>
</div>
</li> 
<li class="portfolio-item bootstrap wordpress">
<div class="item-inner">
<div class="portfolio-image">
<img src="images/portfolio/thumb/item3.jpg" alt="">
<div class="overlay">
<a class="preview btn btn-danger" title="Lorem ipsum dolor sit amet" href="images/portfolio/full/item3.jpg"><i class="icon-eye-open"></i></a>
</div>
</div>
<h5>Lorem ipsum dolor sit amet</h5>
</div>
</li> 
<li class="portfolio-item joomla wordpress apps">
<div class="item-inner">
<div class="portfolio-image">
<img src="images/portfolio/thumb/item4.jpg" alt="">
<div class="overlay">
<a class="preview btn btn-danger" title="Lorem ipsum dolor sit amet" href="images/portfolio/full/item4.jpg"><i class="icon-eye-open"></i></a>
</div>
</div>
<h5>Lorem ipsum dolor sit amet</h5>
</div>
</li> 
<li class="portfolio-item joomla html">
<div class="item-inner">
<div class="portfolio-image">
<img src="images/portfolio/thumb/item5.jpg" alt="">
<div class="overlay">
<a class="preview btn btn-danger" title="Lorem ipsum dolor sit amet" href="images/portfolio/full/item5.jpg"><i class="icon-eye-open"></i></a>
</div>
</div>
<h5>Lorem ipsum dolor sit amet</h5>
</div>
</li> 
<li class="portfolio-item wordpress html">
<div class="item-inner">
<div class="portfolio-image">
<img src="images/portfolio/thumb/item6.jpg" alt="">
<div class="overlay">
<a class="preview btn btn-danger" title="Lorem ipsum dolor sit amet" href="images/portfolio/full/item6.jpg"><i class="icon-eye-open"></i></a>
</div>
</div>
<h5>Lorem ipsum dolor sit amet</h5>
</div>
</li> 
<li class="portfolio-item joomla html">
<div class="item-inner">
<div class="portfolio-image">
<img src="images/portfolio/thumb/item5.jpg" alt="">
<div class="overlay">
<a class="preview btn btn-danger" title="Lorem ipsum dolor sit amet" href="images/portfolio/full/item5.jpg"><i class="icon-eye-open"></i></a>
</div>
</div>
<h5>Lorem ipsum dolor sit amet</h5>
</div>
</li> 
<li class="portfolio-item wordpress html">
<div class="item-inner">
<div class="portfolio-image">
<img src="images/portfolio/thumb/item6.jpg" alt="">
<div class="overlay">
<a class="preview btn btn-danger" title="Lorem ipsum dolor sit amet" href="images/portfolio/full/item6.jpg"><i class="icon-eye-open"></i></a>
</div>
</div>
<h5>Lorem ipsum dolor sit amet</h5>
</div>
</li> 
</ul>
</div> 
</div> 
</section> 
<section id="pricing">
<div class="container">
<div class="box">
<div class="center">
<h2>See our Pricings</h2>
<p class="lead">Pellentesque habitant morbi tristique senectus et netus et <br>malesuada fames ac turpis egestas.</p>
</div> 
<div class="big-gap"></div>
<div id="pricing-table" class="row">
<div class="col-sm-4">
<ul class="plan">
<li class="plan-name">Basic</li>
<li class="plan-price">$29</li>
<li>5GB Storage</li>
<li>1GB RAM</li>
<li>400GB Bandwidth</li>
<li>10 Email Address</li>
<li>Forum Support</li>
<li class="plan-action"><a href="#" class="btn btn-primary btn-lg">Signup</a></li>
</ul>
</div> 
<div class="col-sm-4">
<ul class="plan featured">
<li class="plan-name">Standard</li>
<li class="plan-price">$49</li>
<li>10GB Storage</li>
<li>2GB RAM</li>
<li>1TB Bandwidth</li>
<li>100 Email Address</li>
<li>Forum Support</li>
<li class="plan-action"><a href="#" class="btn btn-primary btn-lg">Signup</a></li>
</ul>
</div> 
<div class="col-sm-4">
<ul class="plan">
<li class="plan-name">Advanced</li>
<li class="plan-price">$199</li>
<li>30GB Storage</li>
<li>5GB RAM</li>
<li>5TB Bandwidth</li>
<li>1000 Email Address</li>
<li>Forum Support</li>
<li class="plan-action"><a href="#" class="btn btn-primary btn-lg">Signup</a></li>
</ul>
</div> 
</div>
</div>
</div>
</section> 
<section id="about-us">
<div class="container">
<div class="box">
<div class="center">
<h2>Meet the Team</h2>
<p class="lead">Pellentesque habitant morbi tristique senectus et netus et<br>malesuada fames ac turpis egestas.</p>
</div>
<div class="gap"></div>
<div id="team-scroller" class="carousel scale">
<div class="carousel-inner">
<div class="item active">
<div class="row">
<div class="col-sm-4">
<div class="member">
<p><img class="img-responsive img-thumbnail img-circle" src="images/team1.jpg" alt=""></p>
<h3>Agnes Smith<small class="designation">CEO &amp; Founder</small></h3>
</div>
</div>
<div class="col-sm-4">
<div class="member">
<p><img class="img-responsive img-thumbnail img-circle" src="images/team2.jpg" alt=""></p>
<h3>Donald Ford<small class="designation">Senior Vice President</small></h3>
</div>
</div>
<div class="col-sm-4">
<div class="member">
<p><img class="img-responsive img-thumbnail img-circle" src="images/team3.jpg" alt=""></p>
<h3>Karen Richardson<small class="designation">Assitant Vice President</small></h3>
</div>
</div>
</div>
</div>
<div class="item">
<div class="row">
<div class="col-sm-4">
<div class="member">
<p><img class="img-responsive img-thumbnail img-circle" src="images/team3.jpg" alt=""></p>
<h3>David Robbins<small class="designation">Co-Founder</small></h3>
</div>
</div>
<div class="col-sm-4">
<div class="member">
<p><img class="img-responsive img-thumbnail img-circle" src="images/team1.jpg" alt=""></p>
<h3>Philip Mejia<small class="designation">Marketing Manager</small></h3>
</div>
</div>
<div class="col-sm-4">
<div class="member">
<p><img class="img-responsive img-thumbnail img-circle" src="images/team2.jpg" alt=""></p>
<h3>Charles Erickson<small class="designation">Support Manager</small></h3>
</div>
</div>
</div>
</div>
</div>
<a class="left-arrow" href="#team-scroller" data-slide="prev">
<i class="icon-angle-left icon-4x"></i>
</a>
<a class="right-arrow" href="#team-scroller" data-slide="next">
<i class="icon-angle-right icon-4x"></i>
</a>
</div> 
</div> 
</div> 
</section> 
<section id="contact">
<div class="container">
<div class="box last">
<div class="row">
<div class="col-sm-6">
<h1>Contact Form</h1>
<p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</p>
<div class="status alert alert-success" style="display: none"></div>
<form id="main-contact-form" class="contact-form" name="contact-form" method="post" action="http://shapebootstrap.net/demo/html/xeon/sendemail.php" role="form">
<div class="row">
<div class="col-sm-6">
<div class="form-group">
<input type="text" class="form-control" required="required" placeholder="Name">
</div>
</div>
<div class="col-sm-6">
<div class="form-group">
<input type="text" class="form-control" required="required" placeholder="Email address">
</div>
</div>
</div>
<div class="row">
<div class="col-sm-12">
<div class="form-group">
<textarea name="message" id="message" required="required" class="form-control" rows="8" placeholder="Message"></textarea>
</div>
<div class="form-group">
<button type="submit" class="btn btn-danger btn-lg">Send Message</button>
</div>
</div>
</div>
</form>
</div> 
<div class="col-sm-6">
<h1>Our Address</h1>
<div class="row">
<div class="col-md-6">
<address>
<strong>Twitter, Inc.</strong><br>
795 Folsom Ave, Suite 600<br>
San Francisco, CA 94107<br>
<abbr title="Phone">P:</abbr> (123) 456-7890
</address>
</div>
<div class="col-md-6">
<address>
<strong>Twitter, Inc.</strong><br>
795 Folsom Ave, Suite 600<br>
San Francisco, CA 94107<br>
<abbr title="Phone">P:</abbr> (123) 456-7890
</address>
</div>
</div>
<h1>Connect with us</h1>
<div class="row">
<div class="col-md-6">
<ul class="social">
<li><a href="#"><i class="icon-facebook icon-social"></i> Facebook</a></li>
<li><a href="#"><i class="icon-google-plus icon-social"></i> Google Plus</a></li>
<li><a href="#"><i class="icon-pinterest icon-social"></i> Pinterest</a></li>
</ul>
</div>
<div class="col-md-6">
<ul class="social">
<li><a href="#"><i class="icon-linkedin icon-social"></i> Linkedin</a></li>
<li><a href="#"><i class="icon-twitter icon-social"></i> Twitter</a></li>
<li><a href="#"><i class="icon-youtube icon-social"></i> Youtube</a></li>
</ul>
</div>
</div>
</div> 
</div> 
</div> 
</div> 
</section> 
<footer id="footer">
<div class="container">
<div class="row">
<div class="col-sm-6">
&copy; 2013 <a target="_blank" href="http://shapebootstrap.net/" title="Free Twitter Bootstrap WordPress Themes and HTML templates">ShapeBootstrap</a>. All Rights Reserved.
</div>
<div class="col-sm-6">
<img class="pull-right" src="images/shapebootstrap.png" alt="ShapeBootstrap" title="ShapeBootstrap">
</div>
</div>
</div>
</footer> 
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.isotope.min.js"></script>
<script src="js/jquery.prettyPhoto.js"></script>
<script src="js/main.js"></script>




  <div class="modal fade" id="login" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content" style="margin-top:10%;">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Login Form</h4>
        </div>
        <div class="modal-body">
          <p>@include('sessions.create')</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
  <div class="modal fade" id="register" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content" style="margin-top:10%;">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Register Form</h4>
        </div>
        <div class="modal-body">
          <p>Some text in the modal.</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
@if(Session::has('message'))
<?php $message = Session::get("message");?>
    @if(is_array($message))
        <script>alert('@foreach($message as $m) {{$m}} @endforeach')</script>"
    @else
    
        <script>alert('{{$message}}')</script>"

    @endif



    <?php Session::put(['message',""]); ?>
   
@endif

</body>

<!-- Mirrored from shapebootstrap.net/demo/html/xeon/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 12 Feb 2016 21:12:37 GMT -->
</html>


